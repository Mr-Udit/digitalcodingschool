import { CoursesTutorials } from "@/components/assects/constant";
import Footer from "@/components/Footer";
import Header from "@/components/Header";
import Link from "next/link";

export default async function page({ params }) {
  let content;
  const { course } = await params;
  console.log(course);
  if (course === "java") {
    content = CoursesTutorials.find((element) => {
      element.name === "Java";
      console.log(` find method 1 ${element.name}`);
      return element;
    });
    console.log(content);
  } else if (course === "python") {
    content = CoursesTutorials.find((element) => {
      element.name === "Python";
      if (element.name === "Python") {
        console.log(` find method 2 ${element.name}`);
        return element;
      }
    });
    console.log(content);
  } else if (course === "web-development") {
    content = CoursesTutorials.find((element) => {
      element.name === "Web Development";
      if (element.name === "Web Development") {
        console.log(` find method 2 ${element.name}`);
        return element;
      }
    });
    console.log(content);
  }
  console.log(` the content is ${content}`);
  return (
    <>
      <Header />
      <div>
        <h1>{content.name}</h1>
        <div className="container">
          <div className="video">
            video here
          </div>
          <div className="headings">
            {content.headings.map((heading, key) => (
              <button key={key}>
                <Link href={heading.link}>{heading.name}</Link>
              </button>
            ))}
          </div>
        </div>
      </div>
      <Footer />
    </>
  );
}
