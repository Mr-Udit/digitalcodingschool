// import javaThumbnail from  "../images/java_thumbnail.jpg"
// import java_icon from "/java-icon.png"
export const Courses = [
  {
    name: "Java",
    description:
      "Java is a high-level, class-based, object-oriented programming language that is designed to have as few implementation dependencies as possible.",
    image: "/java_thumbnail.jpg",
    link: "/java",
  },
  {
    name: "Python",
    description:
      "Python is an interpreted, high-level and general-purpose programming language. Python's design philosophy emphasizes code readability.",
    image: "/java_thumbnail.jpg",
    link: "/python",
  },
  {
    name: "Web Development",
    description:
      "Python is an interpreted, high-level and general-purpose programming language. Python's design philosophy emphasizes code readability.",
    image: "/java_thumbnail.jpg",
    link: "/web-development",
  },
];

export const Tutorials = [
  {
    name: "java",
    image: "/java-icon.png",
  },
  {
    name: "html",
    image: "/java-icon.png",
  },
  {
    name: "css",
    image: "/java-icon.png",
  },
  {
    name: "javascript",
    image: "/java-icon.png",
  },
  {
    name: "python",
    image: "/java-icon.png",
  },
  {
    name: "react.js",
    image: "/java-icon.png",
  },
  {
    name: "next.js",
    image: "/java-icon.png",
  },
  {
    name: "c",
    image: "/java-icon.png",
  },
  {
    name: "c++",
    image: "/java-icon.png",
  },
];

export const CoursesTutorials = [
  {
    name: "Java",
    headings: [
      { name: "Introduction", link: "/java/introduction" },
      { name: "Variables", link: "/java/variables" },
      { name: "OOP Concepts", link: "/java/oop-concepts" },
      { name: "Collections", link: "/java/collections" },
    ],
  },
  {
    name: "Python",
    headings: [
      { name: "Introduction", link: "/python/introduction" },
      { name: "Variables", link: "/python/variables" },
      { name: "Data Structures", link: "/python/data-structures" },
      { name: "OOP Concepts", link: "/python/oop-concepts" },
    ],
  },
  {
    name: "Web Development",
    headings: [
      { name: "HTML Basics", link: "/webdev/html-basics" },
      { name: "CSS Styling", link: "/webdev/css-styling" },
      { name: "JavaScript Basics", link: "/webdev/js-basics" },
      { name: "React.js", link: "/webdev/reactjs" },
    ],
  },
];
